/**=======================typing animation =======================*/
var typed = new Typed(".typing", {
    strings:[" ", "Software Engineer","Web Designer", "Web Designer", "Graphic Designer", "YouTuber"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})

var typed = new Typed(".type", {
    strings:[" ", "Shifani"],
    typeSpeed:200,
    BackSpeed:100,
    loop:true
})





